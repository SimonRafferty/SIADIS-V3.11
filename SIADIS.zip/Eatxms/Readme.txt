"Eatxms" is a utility to waste RAM in modern laptops.
SIADIS will work well if amount of RAM available to is
4Mb to 16 Mb. It may not run properly if too much physical
RAM is installed. This utility allows creating dummy RAM disk
so only rest of the RAM is visible to SIADIS. You need to create 
the RAM disc with size 4 to 16 Mb less than amount of physical 
RAM installed in your computer.

fifo1 fifo2 and fifo3 are three flavors of the utility
disabling fifo buffer in the serial UART of the com port.
SIADIS gets communication errors if large buffers common
in modern UARTs are present and enabled. If no communications
can be established, use one of the utilities to disable fifo buffer
and try again. 486 or older machines (which use to have only
4...16 bytes buffers in thir FIFOs) are virtually guaranteed 
to work OK without any utilities. Only Pentiums and later 
based machines sometimes present problems.
